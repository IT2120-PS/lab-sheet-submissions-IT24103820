setwd("C:\\Users\\IT24103820\\Desktop\\IT24103820")

#Exercise 

#Q1
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main = "Sales Distribution")

#Q4
summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)


#Q5
get_outliers <- function(z) {
  q1 <- quantile(z, 0.25)
  q3 <- quantile(z, 0.75)
  
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  outliers <- z[z < lb | z > ub]
  print(outliers)
}

outliers <- get_outliers(branch_data$Years_X3)
print(outliers)
